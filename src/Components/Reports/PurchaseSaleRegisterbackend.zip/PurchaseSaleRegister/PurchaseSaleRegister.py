from app import app, db
from sqlalchemy.exc import SQLAlchemyError 
from sqlalchemy import text
from flask import jsonify, request
from flask import Flask, jsonify, request
from flask_mail import Mail, Message
import os

API_URL = os.getenv('API_URL')

def format_dates(task):
    return {
        "Inv_date": task['Inv_date'].strftime('%d-%m-%y') if task['Inv_date'] else None,
        #  "date": task['date'].strftime('%Y-%m-%d') if task['date'] else None,
    }


    
@app.route(API_URL+'/SaleTDS_Register', methods=['GET'])
def SaleTDS_Register():
    try:
        from_date = request.args.get('from_date')
        to_date = request.args.get('toDate')
        CompanyCode=request.args.get('companyCode')
        YearCode=request.args.get('YearCode')
        acCode=request.args.get('acCode')

        print(from_date)
        if not from_date or not to_date:
            return jsonify({'error': 'from_date and to_date are required'}), 400

        with db.session.begin_nested():
            if(acCode == ''):
                query = db.session.execute(text('''
                    select Pan,[Name Of Party] as Name_Of_Party ,Taxable_Amt,CGST,SGST,IGST,Bill_Amount,TDS_Amt,Party_Code,Inv_date,InvoiceNo from qryTCSSaleUnion where Inv_date between :from_date and :to_date
                                                and TDS_Amt !=0 and IsDeleted!=0  and  Company_Code=:CompanyCode and Year_Code= :Year_Code
                '''), {'from_date': from_date, 'to_date': to_date,'Year_Code' : YearCode,'CompanyCode' :CompanyCode})
            else:
                 query = db.session.execute(text('''
                    select Pan,[Name Of Party] as Name_Of_Party ,Taxable_Amt,CGST,SGST,IGST,Bill_Amount,TDS_Amt,Party_Code,Inv_date,InvoiceNo from qryTCSSaleUnion where Inv_date between :from_date and :to_date
                                                and TDS_Amt !=0 and IsDeleted!=0  and  Company_Code=:CompanyCode and Year_Code= :Year_Code and Party_Code= :acCode
                '''), {'from_date': from_date, 'to_date': to_date,'Year_Code' : YearCode,'CompanyCode' :CompanyCode,'acCode' : acCode})
          
            result = query.fetchall()

        response = []
        for row in result:
            row_dict = row._asdict()
            formatted_dates = format_dates(row_dict)
            row_dict.update(formatted_dates)
            response.append(row_dict)

        return jsonify(response)

    except SQLAlchemyError as error:
        print("Error fetching data:", error)
        db.session.rollback()
        return jsonify({'error': 'Internal server error'}), 500

@app.route(API_URL+'/SaleTCS_Register', methods=['GET'])
def SaleTCS_Register():
    try:
        from_date = request.args.get('from_date')
        to_date = request.args.get('toDate')
        CompanyCode=request.args.get('companyCode')
        YearCode=request.args.get('YearCode')
        acCode=request.args.get('acCode')

        print(from_date)
        if not from_date or not to_date:
            return jsonify({'error': 'from_date and to_date are required'}), 400

        with db.session.begin_nested():
            if(acCode == ''):
                query = db.session.execute(text('''
                    select Pan,[Name Of Party] as Name_Of_Party ,Taxable_Amt,CGST,SGST,IGST,Bill_Amount,TCS,Party_Code,Inv_date,InvoiceNo from qryTCSSaleUnion where Inv_date between :from_date and :to_date
                                                and TCS !=0 and IsDeleted!=0  and  Company_Code=:CompanyCode and Year_Code= :Year_Code
                '''), {'from_date': from_date, 'to_date': to_date,'Year_Code' : YearCode,'CompanyCode' :CompanyCode})
            else:
                 query = db.session.execute(text('''
                    select Pan,[Name Of Party] as Name_Of_Party ,Taxable_Amt,CGST,SGST,IGST,Bill_Amount,TCS,Party_Code,Inv_date,InvoiceNo from qryTCSSaleUnion where Inv_date between :from_date and :to_date
                                                and TCS !=0 and IsDeleted!=0  and  Company_Code=:CompanyCode and Year_Code= :Year_Code and Party_Code= :acCode
                '''), {'from_date': from_date, 'to_date': to_date,'Year_Code' : YearCode,'CompanyCode' :CompanyCode,'acCode' : acCode})
          
            result = query.fetchall()

        response = []
        for row in result:
            row_dict = row._asdict()
            formatted_dates = format_dates(row_dict)
            row_dict.update(formatted_dates)
            response.append(row_dict)

        return jsonify(response)

    except SQLAlchemyError as error:
        print("Error fetching data:", error)
        db.session.rollback()
        return jsonify({'error': 'Internal server error'}), 500

@app.route(API_URL+'/PurchaseTCS_Register', methods=['GET'])
def PurchaseTCS_Register():
    try:
        from_date = request.args.get('from_date')
        to_date = request.args.get('toDate')
        CompanyCode=request.args.get('companyCode')
        YearCode=request.args.get('YearCode')
        acCode=request.args.get('acCode')

        print(from_date)
        if not from_date or not to_date:
            return jsonify({'error': 'from_date and to_date are required'}), 400

        with db.session.begin_nested():
            if(acCode == ''):
                query = db.session.execute(text('''
                   select Pan,[Name Of Party] as Name_Of_Party,TCS ,Taxable_Amt,CGST,SGST,IGST,Bill_Amount,TCS,Party_Code,convert(varchar(10),date,103) as date,PSNo,Bill_No,dono from qryTCSPurchaseUnion where date between :from_date and :to_date
                                                and TCS !=0 and  Company_Code=:CompanyCode and Year_Code= :Year_Code
                '''), {'from_date': from_date, 'to_date': to_date,'Year_Code' : YearCode,'CompanyCode' :CompanyCode})
            else:
                 query = db.session.execute(text('''
                    select Pan,[Name Of Party] as Name_Of_Party,TCS ,Taxable_Amt,CGST,SGST,IGST,Bill_Amount,TCS,Party_Code,convert(varchar(10),date,103) as date,PSNo,Bill_No,dono from qryTCSPurchaseUnion where date between :from_date and :to_date
                                                and TCS !=0  and  Company_Code=:CompanyCode and Year_Code= :Year_Code and Party_Code= :acCode
                '''), {'from_date': from_date, 'to_date': to_date,'Year_Code' : YearCode,'CompanyCode' :CompanyCode,'acCode' : acCode})
          
            result = query.fetchall()

        response = []
        for row in result:
            row_dict = row._asdict()
            # formatted_dates = format_dates(row_dict)
            # row_dict.update(formatted_dates)
            response.append(row_dict)

        return jsonify(response)

    except SQLAlchemyError as error:
        print("Error fetching data:", error)
        db.session.rollback()
        return jsonify({'error': 'Internal server error'}), 500
    
@app.route(API_URL+'/PurchaseTDS_Register', methods=['GET'])
def PurchaseTDS_Register():
    try:
        from_date = request.args.get('from_date')
        to_date = request.args.get('toDate')
        CompanyCode=request.args.get('companyCode')
        YearCode=request.args.get('YearCode')
        acCode=request.args.get('acCode')

        print(from_date)
        if not from_date or not to_date:
            return jsonify({'error': 'from_date and to_date are required'}), 400

        with db.session.begin_nested():
            if(acCode == ''):
                query = db.session.execute(text('''
                    select Pan,[Name Of Party] as Name_Of_Party ,TDS_Amt,Taxable_Amt,CGST,SGST,IGST,Bill_Amount,TCS,Party_Code,convert(varchar(10),date,103) as date,PSNo,Bill_No,dono from qryTCSPurchaseUnion where date between :from_date and :to_date
                                                and TDS_Amt !=0 and  Company_Code=:CompanyCode and Year_Code= :Year_Code
                '''), {'from_date': from_date, 'to_date': to_date,'Year_Code' : YearCode,'CompanyCode' :CompanyCode})
            else:
                 query = db.session.execute(text('''
                    select Pan,[Name Of Party] as Name_Of_Party,TDS_Amt ,Taxable_Amt,CGST,SGST,IGST,Bill_Amount,TCS,Party_Code,convert(varchar(10),date,103) as date,PSNo,Bill_No,dono from qryTCSPurchaseUnion where date between :from_date and :to_date
                                                and TDS_Amt !=0  and  Company_Code=:CompanyCode and Year_Code= :Year_Code and Party_Code= :acCode
                '''), {'from_date': from_date, 'to_date': to_date,'Year_Code' : YearCode,'CompanyCode' :CompanyCode,'acCode' : acCode})
          
            result = query.fetchall()

        response = []
        for row in result:
            row_dict = row._asdict()
            # formatted_dates = format_dates(row_dict)
            # row_dict.update(formatted_dates)
            response.append(row_dict)

        return jsonify(response)

    except SQLAlchemyError as error:
        print("Error fetching data:", error)
        db.session.rollback()
        return jsonify({'error': 'Internal server error'}), 500    
