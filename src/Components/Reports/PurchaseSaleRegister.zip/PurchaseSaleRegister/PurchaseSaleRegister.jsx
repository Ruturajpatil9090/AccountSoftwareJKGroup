import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "./PurchaseSaleRegister.css";
import { useNavigate } from "react-router-dom";
import { Typography } from "@mui/material";
import AccountMasterHelp from "../../../Helper/AccountMasterHelp";

const PurchaseSaleRegisterReport = () => {
    const navigate = useNavigate();
    const [fromDate, setFromDate] = useState("");
    const [toDate, setToDate] = useState("");
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");

    const AccountYear = sessionStorage.getItem("Accounting_Year");
    const Year_Code = sessionStorage.getItem("Year_Code");
    const Company_Code = sessionStorage.getItem("Company_Code");

    const [acCode, setAcCode] = useState("");
    const [accoid, setAccoid] = useState("");
    const [acname, setAcname] = useState("");

    useEffect(() => {
        if (AccountYear) {
            const dates = AccountYear.split(" - ");
            if (dates.length === 2) {
                setFromDate(dates[0]);
                setToDate(dates[1]);
            }
        }
    }, [AccountYear]);

    const handleAc_Code = (code, id, name) => {
        setAcCode(code);
        setAccoid(id);
        setAcname(name);
    };

    const handleGetReportClick = (e) => {
        e.preventDefault();
        const isConfirmed = window.confirm("Partywise=>Ok / Summary Report=>Cancel");
        console.log('isConfirmed',isConfirmed)
        if (!isConfirmed) {
            setTimeout(() => {
                const url = `/SaleTDS-registers?fromDate=${encodeURIComponent(fromDate)}&toDate=${encodeURIComponent(toDate)}&companyCode=${encodeURIComponent(Company_Code)}&yearCode=${encodeURIComponent(Year_Code)}&acCode=${encodeURIComponent(acCode)}`;
            
                window.open(url, "_blank", "toolbar=yes,location=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes,width=800,height=600");
                setLoading(false);
            }, 500);
        }
        else
        {
            setTimeout(() => {
                const url = `/SaleTDSPartyWise-registers?fromDate=${encodeURIComponent(fromDate)}&toDate=${encodeURIComponent(toDate)}&companyCode=${encodeURIComponent(Company_Code)}&yearCode=${encodeURIComponent(Year_Code)}&acCode=${encodeURIComponent(acCode)}`;
            
                window.open(url, "_blank", "toolbar=yes,location=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes,width=800,height=600");
                setLoading(false);
            }, 500);
        }
        setLoading(true);
       
        
        
    };

    const handleGetSaleTCSReportClick = (e) => {
        e.preventDefault();
        const isConfirmed = window.confirm("Partywise=>Ok / Summary Report=>Cancel");
        console.log('isConfirmed',isConfirmed)
        if (!isConfirmed) {
            setTimeout(() => {
                const url = `/SaleTCS-registers?fromDate=${encodeURIComponent(fromDate)}&toDate=${encodeURIComponent(toDate)}&companyCode=${encodeURIComponent(Company_Code)}&yearCode=${encodeURIComponent(Year_Code)}&acCode=${encodeURIComponent(acCode)}`;
            
                window.open(url, "_blank", "toolbar=yes,location=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes,width=800,height=600");
                setLoading(false);
            }, 500);
        }
        else
        {
            setTimeout(() => {
                const url = `/SaleTCSPartyWise-registers?fromDate=${encodeURIComponent(fromDate)}&toDate=${encodeURIComponent(toDate)}&companyCode=${encodeURIComponent(Company_Code)}&yearCode=${encodeURIComponent(Year_Code)}&acCode=${encodeURIComponent(acCode)}`;
            
                window.open(url, "_blank", "toolbar=yes,location=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes,width=800,height=600");
                setLoading(false);
            }, 500);
        }
        setLoading(true);    
               
    };

    const handleGetPurchaseTCSReportClick = (e) => {
        e.preventDefault();
        const isConfirmed = window.confirm("Partywise=>Ok / Summary Report=>Cancel");
        console.log('isConfirmed',isConfirmed)
        if (!isConfirmed) {
            setTimeout(() => {
                const url = `/PurchaseTCS-registers?fromDate=${encodeURIComponent(fromDate)}&toDate=${encodeURIComponent(toDate)}&companyCode=${encodeURIComponent(Company_Code)}&yearCode=${encodeURIComponent(Year_Code)}&acCode=${encodeURIComponent(acCode)}`;
            
                window.open(url, "_blank", "toolbar=yes,location=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes,width=800,height=600");
                setLoading(false);
            }, 500);
        }
        else
        {
            setTimeout(() => {
                const url = `/PurchaseTCSpartywise-registers?fromDate=${encodeURIComponent(fromDate)}&toDate=${encodeURIComponent(toDate)}&companyCode=${encodeURIComponent(Company_Code)}&yearCode=${encodeURIComponent(Year_Code)}&acCode=${encodeURIComponent(acCode)}`;
            
                window.open(url, "_blank", "toolbar=yes,location=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes,width=800,height=600");
                setLoading(false);
            }, 500);
        }
        setLoading(true);    
               
    };

    const handleGetPurchaseTDSReportClick = (e) => {
        e.preventDefault();
        const isConfirmed = window.confirm("Partywise=>Ok / Summary Report=>Cancel");
        console.log('isConfirmed',isConfirmed)
        if (!isConfirmed) {
            setTimeout(() => {
                const url = `/PurchaseTDS-registers?fromDate=${encodeURIComponent(fromDate)}&toDate=${encodeURIComponent(toDate)}&companyCode=${encodeURIComponent(Company_Code)}&yearCode=${encodeURIComponent(Year_Code)}&acCode=${encodeURIComponent(acCode)}`;
            
                window.open(url, "_blank", "toolbar=yes,location=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes,width=800,height=600");
                setLoading(false);
            }, 500);
        }
        else
        {
            setTimeout(() => {
                const url = `/PurchaseTDSpartywise-registers?fromDate=${encodeURIComponent(fromDate)}&toDate=${encodeURIComponent(toDate)}&companyCode=${encodeURIComponent(Company_Code)}&yearCode=${encodeURIComponent(Year_Code)}&acCode=${encodeURIComponent(acCode)}`;
            
                window.open(url, "_blank", "toolbar=yes,location=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes,width=800,height=600");
                setLoading(false);
            }, 500);
        }
        setLoading(true);    
               
    };

    return (
        <div className="container" style={{ maxWidth: "900px", margin: "0 auto", padding: "20px" }}>
            <Typography
                variant="h6"
                style={{
                    textAlign: "center",
                    fontSize: "24px",
                    fontWeight: "bold",
                    marginTop: "10px",
                }}
            >
                Purchase Sale Register
            </Typography>

            <div className="grid-container">
                <label htmlFor="AC_CODE" className="form-label">
                    Account Code:
                </label>
                <div className="account-help-container">
                    <AccountMasterHelp
                        onAcCodeClick={handleAc_Code}
                        name="AC_CODE"
                        CategoryName={acname}
                        CategoryCode={acCode}
                        Ac_type=""
                    />
                </div>
            </div>

            <div className="grid-container">
                <label htmlFor="fromDate" className="form-label">From Date:</label>
                <input
                    type="date"
                    id="fromDate"
                    className="form-control"
                    value={fromDate}
                    onChange={(e) => setFromDate(e.target.value)}
                />

                <label htmlFor="toDate" className="form-label">To Date:</label>
                <input
                    type="date"
                    id="toDate"
                    className="form-control"
                    value={toDate}
                    onChange={(e) => setToDate(e.target.value)}
                />
            </div>

            <div className="grid-container">
                <button
                    type="submit"
                    className="submit-button"
                    onClick={handleGetReportClick}
                    disabled={loading}
                >
                    {loading ? "Loading..." : "Sale TDS"}
                </button>
            </div>
            <div className="grid-container">
                <button
                    type="submit"
                    className="submit-button"
                    onClick={handleGetSaleTCSReportClick}
                    disabled={loading}
                >
                    {loading ? "Loading..." : "Sale TCS"}
                </button>
            </div>
            <div className="grid-container">
                <button
                    type="submit"
                    className="submit-button"
                    onClick={handleGetPurchaseTDSReportClick}
                    disabled={loading}
                >
                    {loading ? "Loading..." : "Purchase TDS"}
                </button>
            </div>
            <div className="grid-container">
                <button
                    type="submit"
                    className="submit-button"
                    onClick={handleGetPurchaseTCSReportClick}
                    disabled={loading}
                >
                    {loading ? "Loading..." : "Purchase TCS"}
                </button>
            </div>

            {error && <div className="alert alert-danger">{error}</div>}
        </div>
    );
};

export default PurchaseSaleRegisterReport;
